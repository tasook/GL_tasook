﻿using Ludiq;

namespace Bolt
{
	public sealed class UnitAnalysis : GraphElementAnalysis
	{
		public bool isEntered { get; set; }
	}
}
